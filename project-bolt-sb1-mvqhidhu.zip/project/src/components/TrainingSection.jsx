import React from 'react';
import { GraduationCap, Play, Award, Users, Clock, CheckCircle } from 'lucide-react';

const TrainingSection = () => {
  const courses = [
    {
      title: 'Basic CPR & AED',
      duration: '4 hours',
      level: 'Beginner',
      price: 'Free',
      description: 'Learn life-saving CPR techniques and automated external defibrillator usage',
      features: ['Hands-on practice', 'Certification included', 'Video tutorials']
    },
    {
      title: 'Advanced First Aid',
      duration: '8 hours',
      level: 'Intermediate',
      price: '$49',
      description: 'Comprehensive first aid training for workplace and home emergencies',
      features: ['Interactive scenarios', 'Professional certification', 'Downloadable resources']
    },
    {
      title: 'Pediatric First Aid',
      duration: '6 hours',
      level: 'Specialized',
      price: '$39',
      description: 'Specialized training for infant and child emergency situations',
      features: ['Age-specific techniques', 'Parent-focused content', 'Emergency protocols']
    }
  ];

  return (
    <section id="training" className="py-16 bg-green-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <GraduationCap className="h-8 w-8 text-green-600 mr-3" />
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">First Aid Training</h2>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Professional first aid training courses designed to build confidence and save lives. 
            Learn from certified instructors with hands-on practice.
          </p>
        </div>

        {/* Course Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {courses.map((course, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-200">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                    {course.level}
                  </span>
                  <span className="text-2xl font-bold text-green-600">{course.price}</span>
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-2">{course.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{course.description}</p>
                
                <div className="flex items-center text-sm text-gray-500 mb-4">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>{course.duration}</span>
                </div>

                <ul className="space-y-2 mb-6">
                  {course.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                      <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <button className="w-full bg-green-600 hover:bg-green-700 text-white py-3 px-4 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2">
                  <Play className="h-4 w-4" />
                  <span>Start Course</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Training Stats */}
        <div className="bg-white p-8 rounded-xl shadow-lg">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-green-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">10,000+</div>
              <div className="text-gray-600">Students Trained</div>
            </div>
            <div>
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-green-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">98%</div>
              <div className="text-gray-600">Certification Rate</div>
            </div>
            <div>
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <GraduationCap className="h-8 w-8 text-green-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">50+</div>
              <div className="text-gray-600">Expert Instructors</div>
            </div>
            <div>
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">24/7</div>
              <div className="text-gray-600">Course Access</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrainingSection;