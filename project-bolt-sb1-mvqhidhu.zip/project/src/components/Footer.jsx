import React from 'react';
import { Heart, Phone, Mail, MapPin, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer = () => {
  const footerSections = [
    {
      title: 'Emergency Services',
      links: [
        'Emergency Call',
        'Non-Emergency Support',
        'Crisis Resources',
        'Local Services',
        'International Numbers'
      ]
    },
    {
      title: 'Training & Education',
      links: [
        'CPR Certification',
        'First Aid Basics',
        'Advanced Training',
        'Corporate Programs',
        'Instructor Resources'
      ]
    },
    {
      title: 'Support',
      links: [
        'Help Center',
        'User Guide',
        'Video Tutorials',
        'Community Forum',
        'Contact Support'
      ]
    },
    {
      title: 'Company',
      links: [
        'About Us',
        'Our Mission',
        'Medical Advisory',
        'Partnerships',
        'Careers'
      ]
    }
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Youtube, href: '#', label: 'YouTube' }
  ];

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-8">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8 mb-12">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-red-600 p-2 rounded-lg">
                <Heart className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">FirstAid Pro</h3>
                <p className="text-sm text-gray-400">Emergency Support</p>
              </div>
            </div>
            <p className="text-gray-400 mb-6">
              Professional first aid support and training platform dedicated to saving lives 
              through education, immediate assistance, and comprehensive emergency resources.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-red-500" />
                <span className="text-sm">Emergency: 911 | Support: 1-800-FIRSTAID</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-red-500" />
                <span className="text-sm">support@firstaidpro.com</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-4 w-4 text-red-500" />
                <span className="text-sm">Available nationwide</span>
              </div>
            </div>
          </div>

          {/* Footer Links */}
          {footerSections.map((section, index) => (
            <div key={index}>
              <h4 className="text-white font-semibold mb-4">{section.title}</h4>
              <ul className="space-y-2">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a 
                      href="#" 
                      className="text-gray-400 hover:text-white transition-colors duration-200 text-sm"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Emergency Banner */}
        <div className="bg-red-600 rounded-lg p-6 mb-8">
          <div className="text-center">
            <h3 className="text-white font-bold text-lg mb-2">
              In Case of Emergency - Call 911 Immediately
            </h3>
            <p className="text-red-100 text-sm">
              For life-threatening emergencies, always contact local emergency services first. 
              This platform provides supplementary guidance and support.
            </p>
          </div>
        </div>

        {/* Social Links & Copyright */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            {/* Social Links */}
            <div className="flex items-center space-x-4 mb-4 md:mb-0">
              <span className="text-gray-400 text-sm">Follow us:</span>
              {socialLinks.map((social, index) => {
                const Icon = social.icon;
                return (
                  <a
                    key={index}
                    href={social.href}
                    className="bg-gray-800 hover:bg-gray-700 p-2 rounded-lg transition-colors duration-200"
                    aria-label={social.label}
                  >
                    <Icon className="h-4 w-4" />
                  </a>
                );
              })}
            </div>

            {/* Copyright & Legal */}
            <div className="text-center md:text-right">
              <p className="text-gray-400 text-sm mb-1">
                © 2025 FirstAid Pro. All rights reserved.
              </p>
              <div className="flex flex-wrap justify-center md:justify-end space-x-4 text-xs text-gray-500">
                <a href="#" className="hover:text-gray-300">Privacy Policy</a>
                <a href="#" className="hover:text-gray-300">Terms of Service</a>
                <a href="#" className="hover:text-gray-300">Medical Disclaimer</a>
                <a href="#" className="hover:text-gray-300">Accessibility</a>
              </div>
            </div>
          </div>
        </div>

        {/* Medical Disclaimer */}
        <div className="border-t border-gray-800 pt-6 mt-6">
          <p className="text-gray-500 text-xs text-center">
            <strong>Medical Disclaimer:</strong> The information provided on this platform is for educational purposes only 
            and should not replace professional medical advice. Always seek immediate medical attention for serious injuries 
            or emergencies. FirstAid Pro is not liable for any outcomes resulting from the use of this information.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;