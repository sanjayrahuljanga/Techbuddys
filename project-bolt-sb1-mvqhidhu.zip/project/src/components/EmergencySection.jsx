import React from 'react';
import { AlertTriangle, Phone, MapPin, Clock, Heart } from 'lucide-react';

const EmergencySection = () => {
  const emergencySteps = [
    { step: 1, title: 'Assess the Situation', description: 'Check for dangers and responsiveness' },
    { step: 2, title: 'Call for Help', description: 'Dial emergency services immediately' },
    { step: 3, title: 'Provide First Aid', description: 'Follow guided instructions until help arrives' },
    { step: 4, title: 'Stay Connected', description: 'Maintain contact with emergency services' }
  ];

  return (
    <section id="emergency" className="py-16 bg-red-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <AlertTriangle className="h-8 w-8 text-red-600 mr-3" />
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Emergency Response</h2>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Immediate guidance for life-threatening emergencies. Get step-by-step instructions 
            and connect with emergency services instantly.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Emergency Actions */}
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-red-600">
              <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <Phone className="h-5 w-5 text-red-600 mr-2" />
                Quick Emergency Actions
              </h3>
              <div className="space-y-4">
                <button className="w-full bg-red-600 hover:bg-red-700 text-white p-4 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2">
                  <Phone className="h-5 w-5" />
                  <span>Call Emergency Services</span>
                </button>
                <button className="w-full bg-orange-600 hover:bg-orange-700 text-white p-4 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2">
                  <Heart className="h-5 w-5" />
                  <span>CPR Instructions</span>
                </button>
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2">
                  <MapPin className="h-5 w-5" />
                  <span>Share Location</span>
                </button>
              </div>
            </div>
          </div>

          {/* Emergency Steps */}
          <div className="space-y-4">
            {emergencySteps.map((item) => (
              <div key={item.step} className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-200 flex items-start space-x-4">
                <div className="bg-red-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0">
                  {item.step}
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">{item.title}</h4>
                  <p className="text-gray-600 text-sm">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default EmergencySection;