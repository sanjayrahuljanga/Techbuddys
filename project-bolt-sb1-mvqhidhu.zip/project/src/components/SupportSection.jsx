import React from 'react';
import { HelpCircle, Phone, Mail, MessageCircle, FileText, Clock, CheckCircle } from 'lucide-react';

const SupportSection = () => {
  const supportOptions = [
    {
      icon: Phone,
      title: 'Phone Support',
      description: 'Speak directly with our support team',
      contact: '1-800-FIRSTAID',
      availability: '24/7 Emergency • 9 AM - 6 PM General',
      action: 'Call Now'
    },
    {
      icon: Mail,
      title: 'Email Support',
      description: 'Send us your questions and concerns',
      contact: 'support@firstaidpro.com',
      availability: 'Response within 2 hours',
      action: 'Send Email'
    },
    {
      icon: MessageCircle,
      title: 'Live Chat',
      description: 'Chat with support representatives',
      contact: 'Available on all pages',
      availability: 'Online now',
      action: 'Start Chat'
    }
  ];

  const faqItems = [
    {
      question: 'How quickly can I access emergency guidance?',
      answer: 'Emergency guidance is available instantly through our app. Critical information is accessible without login, and our emergency button connects you directly to local emergency services.'
    },
    {
      question: 'Are the first aid instructions medically approved?',
      answer: 'Yes, all our first aid instructions are reviewed and approved by certified medical professionals and follow international first aid guidelines from organizations like the Red Cross and AHA.'
    },
    {
      question: 'Can I use this app offline?',
      answer: 'Essential emergency instructions are cached for offline access. However, for the most current information and to connect with support services, an internet connection is recommended.'
    },
    {
      question: 'How do I get certified after completing training?',
      answer: 'After completing our training modules and passing the assessment, you\'ll receive a digital certification that\'s valid for 2 years. Physical certificates can be mailed upon request.'
    }
  ];

  return (
    <section id="support" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <HelpCircle className="h-8 w-8 text-orange-600 mr-3" />
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">User Support</h2>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            We're here to help you navigate our platform and provide the support you need. 
            Get assistance with technical issues, training questions, or emergency guidance.
          </p>
        </div>

        {/* Support Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {supportOptions.map((option, index) => {
            const Icon = option.icon;
            return (
              <div key={index} className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-200">
                <div className="bg-orange-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="h-6 w-6 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{option.title}</h3>
                <p className="text-gray-600 mb-3">{option.description}</p>
                <div className="mb-4">
                  <p className="font-semibold text-gray-900">{option.contact}</p>
                  <p className="text-sm text-gray-500 flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {option.availability}
                  </p>
                </div>
                <button className="w-full bg-orange-600 hover:bg-orange-700 text-white py-2 px-4 rounded-lg font-medium transition-colors duration-200">
                  {option.action}
                </button>
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* FAQ Section */}
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h3>
            <div className="space-y-4">
              {faqItems.map((item, index) => (
                <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                  <h4 className="font-semibold text-gray-900 mb-2">{item.question}</h4>
                  <p className="text-gray-600 text-sm">{item.answer}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Support Resources */}
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Support Resources</h3>
            <div className="space-y-4">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <FileText className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">User Guide</h4>
                    <p className="text-gray-600 text-sm mb-3">
                      Comprehensive documentation covering all features and functions
                    </p>
                    <button className="text-blue-600 hover:text-blue-700 font-medium text-sm">
                      Download Guide
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-start space-x-4">
                  <div className="bg-green-100 p-3 rounded-lg">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Video Tutorials</h4>
                    <p className="text-gray-600 text-sm mb-3">
                      Step-by-step video guides for platform navigation and first aid techniques
                    </p>
                    <button className="text-green-600 hover:text-green-700 font-medium text-sm">
                      Watch Videos
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 p-3 rounded-lg">
                    <MessageCircle className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Community Forum</h4>
                    <p className="text-gray-600 text-sm mb-3">
                      Connect with other users, share experiences, and get peer support
                    </p>
                    <button className="text-purple-600 hover:text-purple-700 font-medium text-sm">
                      Join Forum
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Emergency Contact */}
            <div className="mt-8 bg-red-50 border border-red-200 p-6 rounded-lg">
              <h4 className="font-semibold text-red-900 mb-2 flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                Emergency Technical Support
              </h4>
              <p className="text-red-700 text-sm mb-3">
                If you're experiencing technical issues during an emergency situation
              </p>
              <button className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg font-medium transition-colors duration-200">
                Call Emergency Tech Support
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SupportSection;