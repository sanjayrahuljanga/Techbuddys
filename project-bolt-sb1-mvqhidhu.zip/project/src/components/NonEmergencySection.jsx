import React from 'react';
import { Phone, MessageCircle, Calendar, FileText } from 'lucide-react';

const NonEmergencySection = () => {
  const services = [
    {
      icon: MessageCircle,
      title: 'Medical Consultation',
      description: 'Connect with healthcare professionals for non-urgent medical advice',
      action: 'Start Chat'
    },
    {
      icon: Calendar,
      title: 'Schedule Appointment',
      description: 'Book appointments with local healthcare providers',
      action: 'Book Now'
    },
    {
      icon: FileText,
      title: 'Health Resources',
      description: 'Access comprehensive health guides and prevention tips',
      action: 'Browse Resources'
    },
    {
      icon: Phone,
      title: 'Nurse Helpline',
      description: '24/7 nurse hotline for medical questions and guidance',
      action: 'Call Now'
    }
  ];

  return (
    <section id="non-emergency" className="py-16 bg-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Non-Emergency Support</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Professional medical guidance and support for non-urgent health concerns. 
            Get expert advice when you need it most.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div key={index} className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
                <div className="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{service.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{service.description}</p>
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg font-medium transition-colors duration-200">
                  {service.action}
                </button>
              </div>
            );
          })}
        </div>

        <div className="mt-12 bg-white p-8 rounded-xl shadow-lg">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">When to Use Non-Emergency Services</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start space-x-2">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></span>
                  <span>Minor injuries or illnesses</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></span>
                  <span>Health questions or concerns</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></span>
                  <span>Medication guidance</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></span>
                  <span>Preventive care advice</span>
                </li>
              </ul>
            </div>
            <div className="bg-blue-50 p-6 rounded-lg">
              <h4 className="font-semibold text-gray-900 mb-2">Need immediate help?</h4>
              <p className="text-gray-600 text-sm mb-4">For life-threatening emergencies, always call emergency services first.</p>
              <button className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg font-medium transition-colors duration-200">
                Emergency Services
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NonEmergencySection;