const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('../models/User');
const Course = require('../models/Course');

const seedDatabase = async () => {
  try {
    // Connect to database
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/firstaid_pro');
    console.log('Connected to MongoDB');

    // Clear existing data
    await User.deleteMany({});
    await Course.deleteMany({});
    console.log('Cleared existing data');

    // Create admin user
    const adminUser = new User({
      name: 'Admin User',
      email: 'admin@firstaidpro.com',
      password: 'admin123',
      role: 'admin'
    });
    await adminUser.save();

    // Create instructor user
    const instructorUser = new User({
      name: 'Dr. Sarah Johnson',
      email: 'instructor@firstaidpro.com',
      password: 'instructor123',
      role: 'instructor',
      profile: {
        phone: '+1-555-0123',
        emergencyContact: {
          name: 'Emergency Contact',
          phone: '+1-555-0124',
          relationship: 'Spouse'
        }
      }
    });
    await instructorUser.save();

    // Create sample courses
    const courses = [
      {
        title: 'Basic CPR & AED',
        description: 'Learn life-saving CPR techniques and automated external defibrillator usage',
        level: 'Beginner',
        duration: { hours: 4, minutes: 0 },
        price: 0,
        category: 'CPR',
        instructor: instructorUser._id,
        modules: [
          {
            title: 'Introduction to CPR',
            description: 'Understanding the basics of cardiopulmonary resuscitation',
            content: 'CPR is a life-saving technique that combines chest compressions with rescue breathing...',
            duration: 30,
            order: 1,
            quiz: [
              {
                question: 'What does CPR stand for?',
                options: [
                  { text: 'Cardiopulmonary Resuscitation', isCorrect: true },
                  { text: 'Cardiac Pressure Relief', isCorrect: false },
                  { text: 'Chest Pressure Rescue', isCorrect: false }
                ],
                explanation: 'CPR stands for Cardiopulmonary Resuscitation, a technique to maintain blood flow and breathing.'
              }
            ]
          },
          {
            title: 'Adult CPR Technique',
            description: 'Step-by-step adult CPR procedure',
            content: 'For adult CPR, place the heel of your hand on the center of the chest...',
            duration: 45,
            order: 2
          },
          {
            title: 'AED Usage',
            description: 'How to use an Automated External Defibrillator',
            content: 'An AED is a portable device that checks heart rhythm and can send an electric shock...',
            duration: 30,
            order: 3
          }
        ],
        certification: {
          isAvailable: true,
          validityPeriod: 24
        }
      },
      {
        title: 'Advanced First Aid',
        description: 'Comprehensive first aid training for workplace and home emergencies',
        level: 'Intermediate',
        duration: { hours: 8, minutes: 0 },
        price: 49,
        category: 'First Aid',
        instructor: instructorUser._id,
        modules: [
          {
            title: 'Assessment and Scene Safety',
            description: 'How to assess emergencies and ensure scene safety',
            content: 'Before providing first aid, always ensure the scene is safe...',
            duration: 60,
            order: 1
          },
          {
            title: 'Wound Care and Bleeding Control',
            description: 'Managing different types of wounds and controlling bleeding',
            content: 'Proper wound care prevents infection and promotes healing...',
            duration: 90,
            order: 2
          },
          {
            title: 'Shock and Medical Emergencies',
            description: 'Recognizing and treating shock and common medical emergencies',
            content: 'Shock is a life-threatening condition that requires immediate attention...',
            duration: 75,
            order: 3
          }
        ],
        certification: {
          isAvailable: true,
          validityPeriod: 24
        }
      },
      {
        title: 'Pediatric First Aid',
        description: 'Specialized training for infant and child emergency situations',
        level: 'Specialized',
        duration: { hours: 6, minutes: 0 },
        price: 39,
        category: 'Pediatric',
        instructor: instructorUser._id,
        modules: [
          {
            title: 'Child Development and Safety',
            description: 'Understanding child development stages and safety considerations',
            content: 'Children have different physiological needs and responses to emergencies...',
            duration: 45,
            order: 1
          },
          {
            title: 'Pediatric CPR',
            description: 'CPR techniques for infants and children',
            content: 'Pediatric CPR differs from adult CPR in compression depth and technique...',
            duration: 60,
            order: 2
          },
          {
            title: 'Common Childhood Emergencies',
            description: 'Managing common emergencies specific to children',
            content: 'Children are prone to specific types of injuries and medical emergencies...',
            duration: 75,
            order: 3
          }
        ],
        certification: {
          isAvailable: true,
          validityPeriod: 24
        }
      }
    ];

    const savedCourses = await Course.insertMany(courses);
    console.log(`Created ${savedCourses.length} courses`);

    // Create sample regular user
    const regularUser = new User({
      name: 'John Doe',
      email: 'user@example.com',
      password: 'user123',
      role: 'user',
      profile: {
        phone: '+1-555-0125',
        emergencyContact: {
          name: 'Jane Doe',
          phone: '+1-555-0126',
          relationship: 'Spouse'
        },
        medicalInfo: {
          allergies: ['Penicillin'],
          bloodType: 'O+'
        }
      },
      training: {
        completedCourses: [
          {
            courseId: savedCourses[0]._id,
            completedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
            certificateId: 'CERT-' + Date.now() + '-ABC123',
            expiresAt: new Date(Date.now() + 24 * 30 * 24 * 60 * 60 * 1000) // 24 months from completion
          }
        ],
        currentCourses: [
          {
            courseId: savedCourses[1]._id,
            progress: 45,
            startedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) // 7 days ago
          }
        ]
      }
    });
    await regularUser.save();

    console.log('Database seeded successfully!');
    console.log('Sample users created:');
    console.log('- Admin: admin@firstaidpro.com / admin123');
    console.log('- Instructor: instructor@firstaidpro.com / instructor123');
    console.log('- User: user@example.com / user123');

    process.exit(0);
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
};

seedDatabase();