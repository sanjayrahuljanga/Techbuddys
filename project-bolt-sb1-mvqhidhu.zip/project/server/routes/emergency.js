const express = require('express');
const EmergencyLog = require('../models/EmergencyLog');
const { v4: uuidv4 } = require('uuid');

const router = express.Router();

// Start emergency session
router.post('/start', async (req, res) => {
  try {
    const { type, location, details } = req.body;
    
    const sessionId = uuidv4();
    
    const emergencyLog = new EmergencyLog({
      sessionId,
      type,
      location,
      details,
      user: req.user?.id // Optional, for logged-in users
    });

    await emergencyLog.save();

    res.status(201).json({
      success: true,
      sessionId,
      message: 'Emergency session started',
      emergencyNumbers: {
        general: '911',
        poison: '1-800-222-1222',
        suicide: '988'
      }
    });
  } catch (error) {
    console.error('Emergency start error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to start emergency session'
    });
  }
});

// Update emergency session
router.put('/session/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const { action, details, emergencyServices } = req.body;

    const emergencyLog = await EmergencyLog.findOne({ sessionId });
    if (!emergencyLog) {
      return res.status(404).json({
        success: false,
        message: 'Emergency session not found'
      });
    }

    // Add action to log
    if (action) {
      emergencyLog.actions.push({
        action,
        notes: details?.notes
      });
    }

    // Update emergency services info
    if (emergencyServices) {
      emergencyLog.emergencyServices = {
        ...emergencyLog.emergencyServices,
        ...emergencyServices
      };
    }

    // Update other details
    if (details) {
      emergencyLog.details = {
        ...emergencyLog.details,
        ...details
      };
    }

    await emergencyLog.save();

    res.json({
      success: true,
      message: 'Emergency session updated'
    });
  } catch (error) {
    console.error('Emergency update error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update emergency session'
    });
  }
});

// Get CPR instructions
router.get('/cpr-instructions', (req, res) => {
  const instructions = {
    adult: [
      {
        step: 1,
        title: 'Check Responsiveness',
        description: 'Tap shoulders and shout "Are you okay?"',
        duration: '5-10 seconds'
      },
      {
        step: 2,
        title: 'Call for Help',
        description: 'Call 911 and get an AED if available',
        duration: 'Immediate'
      },
      {
        step: 3,
        title: 'Position Hands',
        description: 'Place heel of hand on center of chest, between nipples',
        duration: '5 seconds'
      },
      {
        step: 4,
        title: 'Start Compressions',
        description: 'Push hard and fast at least 2 inches deep, 100-120 per minute',
        duration: 'Continuous'
      },
      {
        step: 5,
        title: 'Give Rescue Breaths',
        description: 'Tilt head back, lift chin, give 2 breaths after 30 compressions',
        duration: '30:2 ratio'
      }
    ],
    child: [
      {
        step: 1,
        title: 'Check Responsiveness',
        description: 'Tap shoulders gently and shout',
        duration: '5-10 seconds'
      },
      {
        step: 2,
        title: 'Call for Help',
        description: 'Call 911 and get an AED if available',
        duration: 'Immediate'
      },
      {
        step: 3,
        title: 'Position Hand',
        description: 'Use one or two hands on lower half of breastbone',
        duration: '5 seconds'
      },
      {
        step: 4,
        title: 'Start Compressions',
        description: 'Compress at least 1/3 depth of chest, 100-120 per minute',
        duration: 'Continuous'
      },
      {
        step: 5,
        title: 'Give Rescue Breaths',
        description: 'Smaller breaths, watch for chest rise, 30:2 ratio',
        duration: '30:2 ratio'
      }
    ]
  };

  res.json({
    success: true,
    instructions
  });
});

// Get first aid guidance
router.get('/first-aid/:condition', (req, res) => {
  const { condition } = req.params;
  
  const firstAidGuides = {
    bleeding: {
      title: 'Severe Bleeding',
      steps: [
        'Apply direct pressure with clean cloth',
        'Elevate the injured area above heart level if possible',
        'Apply pressure to pressure points if bleeding continues',
        'Apply tourniquet only if trained and bleeding is life-threatening',
        'Call 911 for severe bleeding'
      ],
      warnings: ['Do not remove embedded objects', 'Do not use tourniquet unless trained']
    },
    burns: {
      title: 'Burns',
      steps: [
        'Remove from heat source safely',
        'Cool burn with cool (not cold) water for 10-20 minutes',
        'Remove jewelry/clothing before swelling occurs',
        'Cover with sterile, non-adhesive bandage',
        'Seek medical attention for severe burns'
      ],
      warnings: ['Do not use ice', 'Do not apply butter or oils', 'Do not break blisters']
    },
    choking: {
      title: 'Choking',
      steps: [
        'Encourage coughing if person can speak',
        'Give 5 back blows between shoulder blades',
        'Give 5 abdominal thrusts (Heimlich maneuver)',
        'Alternate back blows and abdominal thrusts',
        'Call 911 if object not dislodged'
      ],
      warnings: ['Do not perform on pregnant women or infants under 1 year']
    },
    fracture: {
      title: 'Suspected Fracture',
      steps: [
        'Do not move the person unless in immediate danger',
        'Immobilize the injured area',
        'Apply ice wrapped in cloth to reduce swelling',
        'Check circulation below the injury',
        'Seek immediate medical attention'
      ],
      warnings: ['Do not try to realign bones', 'Do not give food or water']
    }
  };

  const guide = firstAidGuides[condition.toLowerCase()];
  
  if (!guide) {
    return res.status(404).json({
      success: false,
      message: 'First aid guide not found for this condition'
    });
  }

  res.json({
    success: true,
    guide
  });
});

// End emergency session
router.put('/session/:sessionId/end', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const { notes } = req.body;

    const emergencyLog = await EmergencyLog.findOne({ sessionId });
    if (!emergencyLog) {
      return res.status(404).json({
        success: false,
        message: 'Emergency session not found'
      });
    }

    emergencyLog.status = 'resolved';
    emergencyLog.resolvedAt = new Date();
    if (notes) {
      emergencyLog.notes = notes;
    }

    await emergencyLog.save();

    res.json({
      success: true,
      message: 'Emergency session ended'
    });
  } catch (error) {
    console.error('Emergency end error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to end emergency session'
    });
  }
});

module.exports = router;