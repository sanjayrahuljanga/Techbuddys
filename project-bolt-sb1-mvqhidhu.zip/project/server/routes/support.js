const express = require('express');
const SupportTicket = require('../models/SupportTicket');
const auth = require('../middleware/auth');

const router = express.Router();

// Create support ticket
router.post('/tickets', auth, async (req, res) => {
  try {
    const { subject, description, category, priority = 'medium' } = req.body;

    const ticket = new SupportTicket({
      user: req.user.id,
      subject,
      description,
      category,
      priority,
      messages: [{
        sender: req.user.id,
        content: description,
        timestamp: new Date()
      }]
    });

    await ticket.save();

    res.status(201).json({
      success: true,
      message: 'Support ticket created successfully',
      ticket: {
        id: ticket._id,
        ticketId: ticket.ticketId,
        subject: ticket.subject,
        status: ticket.status,
        priority: ticket.priority,
        createdAt: ticket.createdAt
      }
    });
  } catch (error) {
    console.error('Create ticket error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create support ticket'
    });
  }
});

// Get user's tickets
router.get('/tickets', auth, async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    
    const filter = { user: req.user.id };
    if (status) filter.status = status;

    const tickets = await SupportTicket.find(filter)
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .select('ticketId subject category priority status createdAt');

    const total = await SupportTicket.countDocuments(filter);

    res.json({
      success: true,
      tickets,
      pagination: {
        current: page,
        pages: Math.ceil(total / limit),
        total
      }
    });
  } catch (error) {
    console.error('Get tickets error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch support tickets'
    });
  }
});

// Get ticket by ID
router.get('/tickets/:ticketId', auth, async (req, res) => {
  try {
    const { ticketId } = req.params;

    const ticket = await SupportTicket.findOne({ 
      ticketId, 
      user: req.user.id 
    }).populate('messages.sender', 'name');

    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: 'Support ticket not found'
      });
    }

    res.json({
      success: true,
      ticket
    });
  } catch (error) {
    console.error('Get ticket error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch support ticket'
    });
  }
});

// Add message to ticket
router.post('/tickets/:ticketId/messages', auth, async (req, res) => {
  try {
    const { ticketId } = req.params;
    const { content } = req.body;

    const ticket = await SupportTicket.findOne({ 
      ticketId, 
      user: req.user.id 
    });

    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: 'Support ticket not found'
      });
    }

    ticket.messages.push({
      sender: req.user.id,
      content,
      timestamp: new Date()
    });

    // Update status if ticket was resolved
    if (ticket.status === 'resolved') {
      ticket.status = 'waiting_response';
    }

    await ticket.save();

    res.json({
      success: true,
      message: 'Message added to ticket'
    });
  } catch (error) {
    console.error('Add message error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add message to ticket'
    });
  }
});

// Rate support ticket
router.post('/tickets/:ticketId/rate', auth, async (req, res) => {
  try {
    const { ticketId } = req.params;
    const { rating, feedback } = req.body;

    const ticket = await SupportTicket.findOne({ 
      ticketId, 
      user: req.user.id 
    });

    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: 'Support ticket not found'
      });
    }

    ticket.satisfaction = {
      rating,
      feedback,
      submittedAt: new Date()
    };

    await ticket.save();

    res.json({
      success: true,
      message: 'Thank you for your feedback'
    });
  } catch (error) {
    console.error('Rate ticket error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit rating'
    });
  }
});

// Get FAQ
router.get('/faq', (req, res) => {
  const faq = [
    {
      id: 1,
      question: 'How quickly can I access emergency guidance?',
      answer: 'Emergency guidance is available instantly through our app. Critical information is accessible without login, and our emergency button connects you directly to local emergency services.',
      category: 'emergency'
    },
    {
      id: 2,
      question: 'Are the first aid instructions medically approved?',
      answer: 'Yes, all our first aid instructions are reviewed and approved by certified medical professionals and follow international first aid guidelines from organizations like the Red Cross and AHA.',
      category: 'medical'
    },
    {
      id: 3,
      question: 'Can I use this app offline?',
      answer: 'Essential emergency instructions are cached for offline access. However, for the most current information and to connect with support services, an internet connection is recommended.',
      category: 'technical'
    },
    {
      id: 4,
      question: 'How do I get certified after completing training?',
      answer: 'After completing our training modules and passing the assessment, you\'ll receive a digital certification that\'s valid for 2 years. Physical certificates can be mailed upon request.',
      category: 'training'
    },
    {
      id: 5,
      question: 'What should I do if the app isn\'t working during an emergency?',
      answer: 'Always call 911 first for life-threatening emergencies. Our app is supplementary guidance. If experiencing technical issues during an emergency, call our emergency tech support line.',
      category: 'emergency'
    },
    {
      id: 6,
      question: 'How much do the training courses cost?',
      answer: 'Basic CPR & AED training is free. Advanced courses range from $39-$49. All courses include certification and lifetime access to materials.',
      category: 'billing'
    }
  ];

  const { category } = req.query;
  const filteredFaq = category ? faq.filter(item => item.category === category) : faq;

  res.json({
    success: true,
    faq: filteredFaq
  });
});

module.exports = router;