const express = require('express');
const Course = require('../models/Course');
const User = require('../models/User');
const auth = require('../middleware/auth');

const router = express.Router();

// Get all courses
router.get('/courses', async (req, res) => {
  try {
    const { category, level, page = 1, limit = 10 } = req.query;
    
    const filter = { isActive: true };
    if (category) filter.category = category;
    if (level) filter.level = level;

    const courses = await Course.find(filter)
      .populate('instructor', 'name')
      .sort({ 'rating.average': -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Course.countDocuments(filter);

    res.json({
      success: true,
      courses,
      pagination: {
        current: page,
        pages: Math.ceil(total / limit),
        total
      }
    });
  } catch (error) {
    console.error('Get courses error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch courses'
    });
  }
});

// Get course by ID
router.get('/courses/:id', async (req, res) => {
  try {
    const course = await Course.findById(req.params.id)
      .populate('instructor', 'name profile.phone')
      .populate('prerequisites', 'title');

    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found'
      });
    }

    res.json({
      success: true,
      course
    });
  } catch (error) {
    console.error('Get course error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch course'
    });
  }
});

// Enroll in course
router.post('/courses/:id/enroll', auth, async (req, res) => {
  try {
    const courseId = req.params.id;
    const userId = req.user.id;

    const course = await Course.findById(courseId);
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found'
      });
    }

    const user = await User.findById(userId);
    
    // Check if already enrolled
    const alreadyEnrolled = user.training.currentCourses.some(
      c => c.courseId.toString() === courseId
    );
    
    if (alreadyEnrolled) {
      return res.status(400).json({
        success: false,
        message: 'Already enrolled in this course'
      });
    }

    // Add to current courses
    user.training.currentCourses.push({
      courseId,
      progress: 0,
      startedAt: new Date()
    });

    // Update enrollment count
    course.enrollmentCount += 1;

    await Promise.all([user.save(), course.save()]);

    res.json({
      success: true,
      message: 'Successfully enrolled in course'
    });
  } catch (error) {
    console.error('Enrollment error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to enroll in course'
    });
  }
});

// Update course progress
router.put('/courses/:id/progress', auth, async (req, res) => {
  try {
    const courseId = req.params.id;
    const userId = req.user.id;
    const { moduleIndex, progress } = req.body;

    const user = await User.findById(userId);
    const courseProgress = user.training.currentCourses.find(
      c => c.courseId.toString() === courseId
    );

    if (!courseProgress) {
      return res.status(404).json({
        success: false,
        message: 'Not enrolled in this course'
      });
    }

    courseProgress.progress = Math.max(courseProgress.progress, progress);

    // If course completed (100% progress), move to completed courses
    if (progress >= 100) {
      const course = await Course.findById(courseId);
      const expiresAt = new Date();
      expiresAt.setMonth(expiresAt.getMonth() + course.certification.validityPeriod);

      user.training.completedCourses.push({
        courseId,
        completedAt: new Date(),
        certificateId: `CERT-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
        expiresAt
      });

      // Remove from current courses
      user.training.currentCourses = user.training.currentCourses.filter(
        c => c.courseId.toString() !== courseId
      );
    }

    await user.save();

    res.json({
      success: true,
      message: 'Progress updated successfully',
      completed: progress >= 100
    });
  } catch (error) {
    console.error('Progress update error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update progress'
    });
  }
});

// Get user's training progress
router.get('/my-progress', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id)
      .populate('training.currentCourses.courseId', 'title category level')
      .populate('training.completedCourses.courseId', 'title category level');

    res.json({
      success: true,
      training: user.training
    });
  } catch (error) {
    console.error('Get progress error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch training progress'
    });
  }
});

// Get certificate
router.get('/certificate/:certificateId', auth, async (req, res) => {
  try {
    const { certificateId } = req.params;
    const userId = req.user.id;

    const user = await User.findById(userId)
      .populate('training.completedCourses.courseId', 'title category certification');

    const certificate = user.training.completedCourses.find(
      c => c.certificateId === certificateId
    );

    if (!certificate) {
      return res.status(404).json({
        success: false,
        message: 'Certificate not found'
      });
    }

    res.json({
      success: true,
      certificate: {
        id: certificate.certificateId,
        course: certificate.courseId.title,
        category: certificate.courseId.category,
        completedAt: certificate.completedAt,
        expiresAt: certificate.expiresAt,
        recipient: user.name,
        isValid: certificate.expiresAt > new Date()
      }
    });
  } catch (error) {
    console.error('Get certificate error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch certificate'
    });
  }
});

module.exports = router;