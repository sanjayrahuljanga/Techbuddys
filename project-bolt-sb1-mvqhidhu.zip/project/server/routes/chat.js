const express = require('express');
const ChatSession = require('../models/ChatSession');
const { v4: uuidv4 } = require('uuid');

const router = express.Router();

// Start chat session
router.post('/start', async (req, res) => {
  try {
    const { type = 'ai_chat' } = req.body;
    const sessionId = uuidv4();

    const chatSession = new ChatSession({
      sessionId,
      type,
      user: req.user?.id, // Optional for anonymous users
      messages: [{
        sender: 'ai',
        content: 'Hello! I\'m your AI first aid assistant. How can I help you today?',
        timestamp: new Date()
      }]
    });

    await chatSession.save();

    res.status(201).json({
      success: true,
      sessionId,
      message: 'Chat session started'
    });
  } catch (error) {
    console.error('Chat start error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to start chat session'
    });
  }
});

// Send message
router.post('/session/:sessionId/message', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const { content } = req.body;

    const chatSession = await ChatSession.findOne({ sessionId });
    if (!chatSession) {
      return res.status(404).json({
        success: false,
        message: 'Chat session not found'
      });
    }

    // Add user message
    chatSession.messages.push({
      sender: 'user',
      content,
      timestamp: new Date()
    });

    // Generate AI response (simplified - in production, integrate with AI service)
    const aiResponse = generateAIResponse(content);
    chatSession.messages.push({
      sender: 'ai',
      content: aiResponse.content,
      timestamp: new Date(),
      metadata: {
        confidence: aiResponse.confidence,
        sources: aiResponse.sources
      }
    });

    // Update context based on message content
    updateChatContext(chatSession, content);

    await chatSession.save();

    res.json({
      success: true,
      message: 'Message sent',
      response: aiResponse.content
    });
  } catch (error) {
    console.error('Send message error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to send message'
    });
  }
});

// Get chat history
router.get('/session/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;

    const chatSession = await ChatSession.findOne({ sessionId });
    if (!chatSession) {
      return res.status(404).json({
        success: false,
        message: 'Chat session not found'
      });
    }

    res.json({
      success: true,
      session: chatSession
    });
  } catch (error) {
    console.error('Get chat history error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch chat history'
    });
  }
});

// End chat session
router.put('/session/:sessionId/end', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const { satisfaction } = req.body;

    const chatSession = await ChatSession.findOne({ sessionId });
    if (!chatSession) {
      return res.status(404).json({
        success: false,
        message: 'Chat session not found'
      });
    }

    chatSession.status = 'resolved';
    if (satisfaction) {
      chatSession.satisfaction = satisfaction;
    }

    await chatSession.save();

    res.json({
      success: true,
      message: 'Chat session ended'
    });
  } catch (error) {
    console.error('End chat error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to end chat session'
    });
  }
});

// Helper function to generate AI responses (simplified)
function generateAIResponse(userMessage) {
  const message = userMessage.toLowerCase();
  
  // Emergency keywords
  if (message.includes('emergency') || message.includes('urgent') || message.includes('help')) {
    return {
      content: 'This sounds like an emergency situation. If this is a life-threatening emergency, please call 911 immediately. For non-emergency medical guidance, I can help you with first aid instructions. What specific situation are you dealing with?',
      confidence: 0.9,
      sources: ['Emergency protocols', 'First aid guidelines']
    };
  }
  
  // CPR related
  if (message.includes('cpr') || message.includes('not breathing') || message.includes('unconscious')) {
    return {
      content: 'For CPR: 1) Check responsiveness 2) Call 911 3) Position hands on center of chest 4) Push hard and fast at least 2 inches deep, 100-120 compressions per minute 5) Give 2 rescue breaths after every 30 compressions. Would you like detailed step-by-step instructions?',
      confidence: 0.95,
      sources: ['AHA CPR Guidelines', 'Emergency response protocols']
    };
  }
  
  // Bleeding
  if (message.includes('bleeding') || message.includes('cut') || message.includes('wound')) {
    return {
      content: 'For bleeding: 1) Apply direct pressure with clean cloth 2) Elevate the injured area above heart level if possible 3) If bleeding doesn\'t stop, apply pressure to pressure points 4) Call 911 for severe bleeding. Do not remove embedded objects. Is the bleeding severe or minor?',
      confidence: 0.9,
      sources: ['First aid protocols', 'Wound care guidelines']
    };
  }
  
  // Burns
  if (message.includes('burn') || message.includes('burned')) {
    return {
      content: 'For burns: 1) Remove from heat source safely 2) Cool with cool (not cold) water for 10-20 minutes 3) Remove jewelry before swelling 4) Cover with sterile bandage 5) Seek medical attention for severe burns. Do not use ice, butter, or oils. How severe is the burn?',
      confidence: 0.9,
      sources: ['Burn treatment guidelines', 'Emergency care protocols']
    };
  }
  
  // Choking
  if (message.includes('choking') || message.includes('can\'t breathe')) {
    return {
      content: 'For choking: 1) If person can speak/cough, encourage coughing 2) Give 5 back blows between shoulder blades 3) Give 5 abdominal thrusts (Heimlich) 4) Alternate back blows and thrusts 5) Call 911 if object not dislodged. Is the person able to speak or cough?',
      confidence: 0.95,
      sources: ['Choking response protocols', 'Heimlich maneuver guidelines']
    };
  }
  
  // Default response
  return {
    content: 'I can help you with first aid guidance, emergency procedures, and medical questions. Some topics I can assist with include CPR, bleeding, burns, choking, fractures, and general first aid. What specific situation would you like help with?',
    confidence: 0.7,
    sources: ['General first aid knowledge base']
  };
}

// Helper function to update chat context
function updateChatContext(chatSession, message) {
  const message_lower = message.toLowerCase();
  
  // Determine urgency
  if (message_lower.includes('emergency') || message_lower.includes('urgent') || message_lower.includes('911')) {
    chatSession.context.urgency = 'critical';
  } else if (message_lower.includes('pain') || message_lower.includes('bleeding') || message_lower.includes('injury')) {
    chatSession.context.urgency = 'high';
  } else if (message_lower.includes('help') || message_lower.includes('advice')) {
    chatSession.context.urgency = 'medium';
  }
  
  // Add relevant tags
  const tags = [];
  if (message_lower.includes('cpr')) tags.push('cpr');
  if (message_lower.includes('bleeding')) tags.push('bleeding');
  if (message_lower.includes('burn')) tags.push('burns');
  if (message_lower.includes('choking')) tags.push('choking');
  if (message_lower.includes('fracture') || message_lower.includes('broken')) tags.push('fractures');
  
  chatSession.context.tags = [...new Set([...chatSession.context.tags, ...tags])];
}

module.exports = router;