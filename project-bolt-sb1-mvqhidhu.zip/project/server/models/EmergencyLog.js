const mongoose = require('mongoose');

const emergencyLogSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  sessionId: {
    type: String,
    required: true,
    unique: true
  },
  type: {
    type: String,
    enum: ['emergency_call', 'cpr_guidance', 'first_aid_guidance', 'location_share'],
    required: true
  },
  location: {
    latitude: Number,
    longitude: Number,
    address: String,
    accuracy: Number
  },
  details: {
    symptoms: [String],
    consciousness: {
      type: String,
      enum: ['conscious', 'unconscious', 'semi_conscious']
    },
    breathing: {
      type: String,
      enum: ['normal', 'difficulty', 'not_breathing']
    },
    pulse: {
      type: String,
      enum: ['normal', 'weak', 'strong', 'no_pulse']
    },
    injuries: [String],
    medications: [String],
    allergies: [String]
  },
  actions: [{
    action: String,
    timestamp: {
      type: Date,
      default: Date.now
    },
    notes: String
  }],
  emergencyServices: {
    contacted: {
      type: Boolean,
      default: false
    },
    contactedAt: Date,
    serviceType: String, // ambulance, fire, police
    incidentNumber: String
  },
  status: {
    type: String,
    enum: ['active', 'resolved', 'transferred'],
    default: 'active'
  },
  resolvedAt: Date,
  notes: String
}, {
  timestamps: true
});

// Index for better query performance
emergencyLogSchema.index({ user: 1, createdAt: -1 });
emergencyLogSchema.index({ sessionId: 1 });
emergencyLogSchema.index({ status: 1 });

module.exports = mongoose.model('EmergencyLog', emergencyLogSchema);