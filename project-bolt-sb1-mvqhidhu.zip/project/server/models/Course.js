const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Course title is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Course description is required']
  },
  level: {
    type: String,
    enum: ['Beginner', 'Intermediate', 'Advanced', 'Specialized'],
    required: true
  },
  duration: {
    hours: {
      type: Number,
      required: true,
      min: 1
    },
    minutes: {
      type: Number,
      default: 0,
      min: 0,
      max: 59
    }
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  category: {
    type: String,
    enum: ['CPR', 'First Aid', 'AED', 'Pediatric', 'Workplace Safety', 'Wilderness', 'Mental Health'],
    required: true
  },
  modules: [{
    title: {
      type: String,
      required: true
    },
    description: String,
    content: {
      type: String,
      required: true
    },
    videoUrl: String,
    duration: {
      type: Number, // in minutes
      required: true
    },
    order: {
      type: Number,
      required: true
    },
    quiz: [{
      question: {
        type: String,
        required: true
      },
      options: [{
        text: String,
        isCorrect: Boolean
      }],
      explanation: String
    }]
  }],
  prerequisites: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Course'
  }],
  certification: {
    isAvailable: {
      type: Boolean,
      default: true
    },
    validityPeriod: {
      type: Number, // in months
      default: 24
    },
    certificateTemplate: String
  },
  instructor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  isActive: {
    type: Boolean,
    default: true
  },
  enrollmentCount: {
    type: Number,
    default: 0
  },
  rating: {
    average: {
      type: Number,
      default: 0,
      min: 0,
      max: 5
    },
    count: {
      type: Number,
      default: 0
    }
  }
}, {
  timestamps: true
});

// Index for better query performance
courseSchema.index({ category: 1, level: 1 });
courseSchema.index({ isActive: 1 });
courseSchema.index({ 'rating.average': -1 });

module.exports = mongoose.model('Course', courseSchema);