# FirstAid Pro - Emergency Support & Training Platform

A comprehensive first aid support web application built with React.js frontend and Node.js backend, featuring emergency guidance, training modules, AI chat support, and user management.

## Features

### Frontend (React.js)
- **Emergency Response**: Instant access to emergency guidance and services
- **Non-Emergency Support**: Medical consultation and health resources
- **Training Platform**: Interactive first aid courses with certifications
- **AI Chat Support**: 24/7 AI-powered first aid assistance
- **User Authentication**: Secure login/signup with profile management
- **Support System**: Comprehensive help center and ticket system
- **Responsive Design**: Mobile-first design with modern UI/UX

### Backend (Node.js + Express)
- **RESTful API**: Complete API for all frontend features
- **MongoDB Database**: Robust data storage with Mongoose ODM
- **Authentication**: JWT-based secure authentication
- **Emergency Logging**: Track and log emergency sessions
- **Training Management**: Course enrollment and progress tracking
- **Chat System**: AI chat sessions with context awareness
- **Support Tickets**: Full ticketing system for user support
- **Security**: Rate limiting, CORS, helmet protection

## Tech Stack

### Frontend
- React.js 18
- Tailwind CSS
- Lucide React (icons)
- Vite (build tool)

### Backend
- Node.js
- Express.js
- MongoDB with Mongoose
- JWT Authentication
- bcryptjs (password hashing)
- Express Rate Limit
- Helmet (security)
- CORS

## Getting Started

### Prerequisites
- Node.js (v16 or higher)
- MongoDB (local or cloud instance)
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd firstaid-pro
   ```

2. **Install frontend dependencies**
   ```bash
   npm install
   ```

3. **Install backend dependencies**
   ```bash
   cd server
   npm install
   ```

4. **Environment Setup**
   ```bash
   # In the server directory
   cp .env.example .env
   # Edit .env with your configuration
   ```

5. **Database Setup**
   ```bash
   # Make sure MongoDB is running, then seed the database
   cd server
   npm run seed
   ```

### Running the Application

#### Development Mode (Both Frontend & Backend)
```bash
# From the root directory
npm run dev:full
```

#### Individual Services
```bash
# Frontend only (from root)
npm run dev

# Backend only (from server directory)
cd server
npm run dev
```

The application will be available at:
- Frontend: http://localhost:5173
- Backend API: http://localhost:3000

### Sample Users (After Seeding)
- **Admin**: admin@firstaidpro.com / admin123
- **Instructor**: instructor@firstaidpro.com / instructor123
- **User**: user@example.com / user123

## API Documentation

### Authentication Endpoints
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/verify` - Verify JWT token

### Emergency Endpoints
- `POST /api/emergency/start` - Start emergency session
- `PUT /api/emergency/session/:sessionId` - Update emergency session
- `GET /api/emergency/cpr-instructions` - Get CPR instructions
- `GET /api/emergency/first-aid/:condition` - Get first aid guidance

### Training Endpoints
- `GET /api/training/courses` - Get all courses
- `GET /api/training/courses/:id` - Get course details
- `POST /api/training/courses/:id/enroll` - Enroll in course
- `PUT /api/training/courses/:id/progress` - Update progress
- `GET /api/training/my-progress` - Get user's training progress

### Chat Endpoints
- `POST /api/chat/start` - Start chat session
- `POST /api/chat/session/:sessionId/message` - Send message
- `GET /api/chat/session/:sessionId` - Get chat history

### Support Endpoints
- `POST /api/support/tickets` - Create support ticket
- `GET /api/support/tickets` - Get user's tickets
- `GET /api/support/faq` - Get FAQ

### User Endpoints
- `GET /api/users/profile` - Get user profile
- `PUT /api/users/profile` - Update user profile
- `PUT /api/users/emergency-contact` - Update emergency contact
- `PUT /api/users/medical-info` - Update medical information

## Database Models

### User Model
- Personal information and authentication
- Emergency contacts and medical information
- Training progress and certifications
- Preferences and settings

### Course Model
- Course details and modules
- Instructor information
- Certification settings
- Enrollment tracking

### Emergency Log Model
- Emergency session tracking
- Location and incident details
- Actions taken and timeline
- Emergency services coordination

### Chat Session Model
- AI chat conversations
- Message history and context
- Session management
- User satisfaction tracking

### Support Ticket Model
- User support requests
- Message threads
- Priority and status tracking
- Resolution management

## Security Features

- JWT-based authentication
- Password hashing with bcryptjs
- Rate limiting on API endpoints
- CORS protection
- Helmet security headers
- Input validation and sanitization
- Secure session management

## Deployment

### Frontend Deployment (Netlify)
The frontend is configured for easy deployment to Netlify:
```bash
npm run build
# Deploy the dist/ folder to Netlify
```

### Backend Deployment
For production deployment:
1. Set up MongoDB Atlas or your preferred MongoDB hosting
2. Configure environment variables
3. Deploy to your preferred hosting service (Heroku, DigitalOcean, AWS, etc.)

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@firstaidpro.com or create an issue in the repository.

## Disclaimer

This application provides educational first aid information and should not replace professional medical advice. Always seek immediate medical attention for serious injuries or emergencies.